/*
 * File:   LED.c
 * Author: 14036
 *
 * Created on November 25, 2024, 7:14 PM
 */


#include "xc.h"
#pragma config ICS = PGD1               // ICD Communication Channel Select bits (Communicate on PGEC1 and PGED1)

int main(void) {
    TRISAbits.TRISA1 = 0; //Designate this pin as an output 
    LATAbits.LATA1 = 1;  // Turn on LED connected to RA1
    return 0;
}
